package com.bazaarhelper.mixin;

import com.bazaarhelper.gui.BazaarOverlayManager;
import com.bazaarhelper.util.BazaarOrderParser;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(class_465.class)
public abstract class HandledScreenMixin extends class_437 {

    protected HandledScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "close", at = @At("HEAD"))
    private void onClose(CallbackInfo ci) {
        String title = BazaarOrderParser.stripFormatting(this.method_25440().getString());
        if (BazaarOrderParser.isBazaarOrderScreen(title)) {
            BazaarOverlayManager.clear();
        }
    }
}
