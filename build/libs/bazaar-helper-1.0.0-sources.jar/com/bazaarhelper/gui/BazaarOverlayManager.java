package com.bazaarhelper.gui;

import com.bazaarhelper.client.BazaarHelperClient;
import com.bazaarhelper.util.BazaarOrder;
import com.bazaarhelper.util.BazaarOrderParser;
import com.bazaarhelper.util.PickupSellAutomation;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_1703;
import net.minecraft.class_310;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.List;


public class BazaarOverlayManager {

    private static BazaarOrderPanel activePanel = null;
    private static boolean lastLeftMouseDown = false;

    private static final Field FIELD_BG_WIDTH;
    private static final Field FIELD_BG_HEIGHT;

    static {
        Field w = null, h = null;
        for (Class<?> cls = class_465.class; cls != null; cls = cls.getSuperclass()) {
            for (Field f : cls.getDeclaredFields()) {
                f.setAccessible(true);
                String n = f.getName();
                if (f.getType() == int.class) {
                    if (n.equals("backgroundWidth")  || n.equals("field_22793")) w = f;
                    if (n.equals("backgroundHeight") || n.equals("field_22794")) h = f;
                }
            }
            if (w != null && h != null) break;
        }
        FIELD_BG_WIDTH  = w;
        FIELD_BG_HEIGHT = h;

        if (FIELD_BG_WIDTH  == null) BazaarHelperClient.LOGGER.warn("[BH] backgroundWidth field not found");
        if (FIELD_BG_HEIGHT == null) BazaarHelperClient.LOGGER.warn("[BH] backgroundHeight field not found");
    }

    private static int getBgWidth(class_465<?> screen) {
        try { return FIELD_BG_WIDTH  != null ? (int) FIELD_BG_WIDTH.get(screen)  : 176; }
        catch (IllegalAccessException e) { return 176; }
    }

    private static int getBgHeight(class_465<?> screen) {
        try { return FIELD_BG_HEIGHT != null ? (int) FIELD_BG_HEIGHT.get(screen) : 222; }
        catch (IllegalAccessException e) { return 222; }
    }

    public static void onScreenOpen(class_310 client, class_465<?> screen) {
        String title = BazaarOrderParser.stripFormatting(screen.method_25440().getString());

        if (!BazaarOrderParser.isBazaarOrderScreen(title)) {
            activePanel = null;
            return;
        }

        BazaarHelperClient.LOGGER.info("[BH] Bazaar order screen: '{}'", title);
        class_1703 handler = screen.method_17577();
        lastLeftMouseDown = false;

        rebuildPanel(screen, handler, title);

        ScreenEvents.afterRender(screen).register((scr, ctx, mx, my, delta) -> {
            if (activePanel != null) {
                activePanel.render(ctx, client.field_1772, mx, my);

                boolean leftMouseDown = GLFW.glfwGetMouseButton(
                        client.method_22683().method_4490(),
                        GLFW.GLFW_MOUSE_BUTTON_LEFT
                ) == GLFW.GLFW_PRESS;

                if (leftMouseDown && !lastLeftMouseDown) {
                    BazaarOrder clicked = activePanel.onMouseClick(mx, my);
                    PickupSellAutomation automation = PickupSellAutomation.getInstance();
                    if (clicked != null && automation != null && !automation.isRunning()) {
                        BazaarHelperClient.LOGGER.info("[BH] Button clicked for: {}", clicked);
                        automation.start(clicked);
                    }
                }

                lastLeftMouseDown = leftMouseDown;
            }
        });


        final int[] tickCounter = {0};
        ScreenEvents.afterTick(screen).register(scr -> {
            tickCounter[0]++;
            if (tickCounter[0] >= 20) {
                tickCounter[0] = 0;
                rebuildPanel(screen, handler, title);
            }
        });
    }

    private static void rebuildPanel(class_465<?> screen,
                                     class_1703 handler, String title) {
        List<BazaarOrder> orders = BazaarOrderParser.parseOrders(handler, title);

        int guiW = getBgWidth(screen);
        int guiH = getBgHeight(screen);
        int scrX = (screen.field_22789  - guiW) / 2;
        int scrY = (screen.field_22790 - guiH) / 2;

        activePanel = new BazaarOrderPanel(
                orders, scrX, scrY, guiW, guiH,
                screen.field_22789, screen.field_22790
        );
    }

    public static void clear() {
        activePanel = null;
        lastLeftMouseDown = false;
    }
}
