package com.bazaarhelper.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

public class BazaarOrderParser {

    private static final Pattern AMOUNT_PATTERN =
            Pattern.compile("(?:Amount|Filled|Claimable|Items to Claim):\\s*([\\d.,]+[kmb]?)\\s*/\\s*([\\d.,]+[kmb]?)",
                    Pattern.CASE_INSENSITIVE);

    private static final Pattern GENERIC_AMOUNT_PATTERN =
            Pattern.compile("([\\d.,]+[kmb]?)\\s*/\\s*([\\d.,]+[kmb]?)", Pattern.CASE_INSENSITIVE);

    private static final Pattern PRICE_PATTERN =
            Pattern.compile("Price per unit:\\s*([\\d,.]+)\\s*coins");

    private static final Pattern TEXT_FIELD_PATTERN =
            Pattern.compile("\"text\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"");

    public static List<BazaarOrder> parseOrders(class_1703 handler, String screenTitle) {
        List<BazaarOrder> result = new ArrayList<>();
        if (!isBazaarOrderScreen(screenTitle)) {
            return result;
        }

        int max = Math.min(handler.field_7761.size(), 45);
        for (int slot = 0; slot < max; slot++) {
            class_1799 stack = handler.field_7761.get(slot).method_7677();
            if (stack.method_7960()) {
                continue;
            }

            BazaarOrder order = tryParseSlot(stack, slot);
            if (order != null && order.hasItemsToClaim()) {
                result.add(order);
            }
        }
        return result;
    }

    public static BazaarOrder tryParseSlot(class_1799 stack, int slot) {
        if (stack.method_7960()) {
            return null;
        }

        List<String> loreLines = getRawLore(stack);
        if (loreLines.isEmpty()) {
            return null;
        }

        String itemName = stripFormatting(stack.method_7964().getString());
        String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        long filled = -1;
        long total = -1;
        double price = 0;

        for (String line : loreLines) {
            String plain = stripFormatting(line);

            Matcher amountMatcher = AMOUNT_PATTERN.matcher(plain);
            if (amountMatcher.find()) {
                filled = parseLong(amountMatcher.group(1));
                total = parseLong(amountMatcher.group(2));
            } else {
                Matcher genericAmountMatcher = GENERIC_AMOUNT_PATTERN.matcher(plain);
                if (genericAmountMatcher.find()) {
                    filled = parseLong(genericAmountMatcher.group(1));
                    total = parseLong(genericAmountMatcher.group(2));
                }
            }

            Matcher priceMatcher = PRICE_PATTERN.matcher(plain);
            if (priceMatcher.find()) {
                price = parseDouble(priceMatcher.group(1));
            }
        }

        if (filled < 0 || total <= 0) {
            return null;
        }

        return new BazaarOrder(itemName, itemId, filled, total, price, slot);
    }

    public static boolean isBazaarScreen(String title) {
        return title.contains("Bazaar") || title.contains("Co-op Bazaar");
    }

    public static boolean isBazaarOrderScreen(String title) {
        return title.contains("Your Bazaar Orders")
                || title.contains("Manage Orders")
                || title.contains("Bazaar Orders");
    }

    public static boolean isBazaarManageOrderScreen(String title) {
        return title.contains("Manage Order") || title.contains("Collect Items");
    }

    public static boolean isBoosterCookieScreen(String title) {
        return title.contains("Booster Cookie") || title.contains("Cookie Menu");
    }

    public static boolean isSkyblockMenu(String title) {
        return title.equals("SkyBlock Menu") || title.contains("Sky Block Menu");
    }

    public static List<String> getLoreLines(class_1799 stack) {
        return getRawLore(stack);
    }

    private static List<String> getRawLore(class_1799 stack) {
        List<String> lines = new ArrayList<>();

        try {
            var loreComponent = stack.method_58694(class_9334.field_49632);
            if (loreComponent != null) {
                for (class_2561 text : loreComponent.comp_2400()) {
                    lines.add(text.getString());
                }
                if (!lines.isEmpty()) {
                    return lines;
                }
            }
        } catch (Exception ignored) {
        }

        try {
            var customData = stack.method_58694(class_9334.field_49628);
            class_2487 customDataNbt = customData != null ? customData.method_57461() : null;
            if (customDataNbt == null || !customDataNbt.method_10545("display")) {
                return lines;
            }

            class_2487 display = customDataNbt.method_10562("display").orElse(null);
            if (display == null) {
                return lines;
            }
            if (!display.method_10545("Lore")) {
                return lines;
            }

            class_2499 loreList = display.method_10554("Lore").orElse(null);
            if (loreList == null) {
                return lines;
            }
            for (int i = 0; i < loreList.size(); i++) {
                String raw = loreList.method_10608(i).orElse("");
                lines.add(extractTextFromJson(raw));
            }
        } catch (Exception ignored) {
        }

        return lines;
    }

    private static String extractTextFromJson(String raw) {
        Matcher matcher = TEXT_FIELD_PATTERN.matcher(raw);
        StringBuilder builder = new StringBuilder();

        while (matcher.find()) {
            builder.append(unescapeJson(matcher.group(1)));
        }

        String extracted = builder.toString().trim();
        return extracted.isEmpty() ? raw : extracted;
    }

    private static String unescapeJson(String text) {
        return text
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "")
                .replace("\\r", "")
                .replace("\\t", " ");
    }

    public static String stripFormatting(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        return s.replaceAll("[\\u00A7&][0-9a-fk-orA-FK-OR]", "").trim();
    }

    public static long parseLong(String s) {
        try {
            String normalized = s.trim().toLowerCase().replace(",", "");
            long multiplier = 1L;

            if (normalized.endsWith("k")) {
                multiplier = 1_000L;
                normalized = normalized.substring(0, normalized.length() - 1);
            } else if (normalized.endsWith("m")) {
                multiplier = 1_000_000L;
                normalized = normalized.substring(0, normalized.length() - 1);
            } else if (normalized.endsWith("b")) {
                multiplier = 1_000_000_000L;
                normalized = normalized.substring(0, normalized.length() - 1);
            }

            return Math.round(Double.parseDouble(normalized) * multiplier);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static double parseDouble(String s) {
        try {
            return Double.parseDouble(s.replace(",", ""));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static String formatNumber(long n) {
        return String.format("%,d", n);
    }

    public static String formatCoins(double coins) {
        if (coins >= 1_000_000) {
            return String.format("%.2fM", coins / 1_000_000);
        }
        if (coins >= 1_000) {
            return String.format("%.1fk", coins / 1_000);
        }
        return String.format("%.0f", coins);
    }
}
